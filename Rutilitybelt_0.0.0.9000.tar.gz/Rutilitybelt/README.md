# Rutilitybelt

Some miscellaneous useful R code put together by the SESYNC Cyberhelp team for themselves and SESYNC users.

## How to install

Type this into your R prompt the first time you want to use this package, or if you want to get the latest package updates.

```
remotes::install_gitlab('ci-misc/r-utility-belt', host = 'gitlab.sesync.org')
```

## How to load

Type this into your R prompt every time you want to run functions from this package.

```
library(Rutilitybelt)
```

*last modified by QDR, 12 Feb 2021*

